/*
 * Program.cs is the starting point for AGMGSK applications.
 *
 * 
 * Group member:  Sam Mouradian , Anton Vilekodneyy, Danny Pena
 * Project 1
 * Comp 565 Spring 2016
 * 
 * 
 * 
 * ***********************************
 *  THEME
 * ***********************************
 * 
 *  ^^^ King Arthur Meets Anime ^^^
 *  Temple -----> Castle
 *  Dogs -------> Wild Beasts
 *  Treasure -------> Swords
 *  Main Character --------> Female Version of King Arthur
 *  
 *  Models were found at the following website : https://www.models-resource.com/
 *  
 *  
 * 
 * ***********************************
 *  TREASURE 
 * ***********************************
 * 
 * Added TreasureList Class is responsible for generating a list of treasure locations that will spawn on the terrain. 
 * TreasureList is also referenced by the NPAgent when the agent is in 'N' toggle mode to search for untagged treasures.
 * Treasure are tagged by the NPAgent when the agent comes into contact with them. The treausres also spin with the Yaw method
 * of the 3dobject instance of the treasure object.
 * 
 * TreasureList has the property of being collidable, as it inherits from Model3D.
 * Treasures are instantiated at 4 locations, including the required location (447,453)
 * 
 * 
 * ***********************************
 *  MODELS 
 * ***********************************
 * 
 * Models were generated using BLENDER and AC3D software. 
 * Found .dae and .obj files online that contained textures and wireframes for each model.
 * Imported them into blender, packaged the textures files alongside the model and exported as a .obj.
 * Opened the .obj files in AC3D and edited height, width, depth until satisfied with models sizes.
 * Used the Content manager tool to import the models in order to render them on the terrain. 
 * A lot of effort went into modifiying and creating these models, and also trying to get them to render with textures.
 * 
 *  
 * ***********************************
 *  New Key Bindings  
 * ***********************************
 * 
 * New bindings were created in the Stage.cs folder for the 'N' and 'L' keys.
 * The N key toggles the NPAgent changing its path to go to the nearest treasure and deactivate it. 
 * The L key toggles Linear Interpolation in the game.
 * 
 * 
 * ***********************************
 * Height Generation Function 
 * ***********************************
 * 
 * Diamond Square Algorithm was used to implement height map generation in the TerrainMap Project.
 * The follwoing tutorial was essentially taken and converted from javascript to C# for use in the project.
 * Essentially Using fractal and gaussian blurring to smooth out the terrain vertives as well as Noise filter to 
 * better render the terrain color.
 * 
 * 
 * ***********************************
 *  Path Finding
 * ***********************************
 * Implemented a treasure target based path finding that allows the NPAgent to move toward an unmarked Treasure object 
 * by checking to see which is the nearest untagged treasure and navigate toward it in a straight line until the treasure is 
 * tagged and deactiveted by the NPAgent.
 * 
 * 
 * ************************************
 * Lerp Function
 * ***********************************
 * 
 * Implemented Linear Interpolation that can be toggled with the use of the 'N' key to stay on top of terrain. 
 * Lerp functionality is most noticible in this project when travling up more of the steep hills and mountains.
 * Doing an X and Z axis translation to ensure that the distance of the object from the terrain is minimal but still above the 
 * ground. SetSurfaceHeight needed to be modified to account for LERP functionality.
 */

using System;
// using System.Collections;  // needed any more 1/11/2017

namespace AGMGSKv9  {
static class Program {
   /// <summary>
   /// The main entry point for the application.
   /// </summary>
   static void Main(string[] args) {
      using (Stage stage = new Stage()) {
            stage.Run();
      }
   }
}
}

